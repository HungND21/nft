export const regionDropdown = [{ value: 1, label: 'VN' }];
