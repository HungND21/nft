const BACKEND_URL_LOCAL = 'http://localhost:4000/api';
// const BACKEND_URL_HOSTING = 'http://51.89.233.106:4000/api';
// const BACKEND_URL_HOSTING = 'http://107.161.26.33:4000/api';
const BACKEND_URL_HOSTING = 'https://fwar.finance/api';

const BSCTESTNET_TRANSACTION_URL = 'https://testnet.bscscan.com/tx/';
const BSC_TRANSACTION_URL = '';
export { BACKEND_URL_LOCAL, BACKEND_URL_HOSTING, BSCTESTNET_TRANSACTION_URL, BSC_TRANSACTION_URL };
